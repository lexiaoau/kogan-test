# Kogan Code Chanllenge

## Prerequisite

Latest NodeJS is installed.

This program is to be run in NodeJS and written in JavaScript.

## Installation

```
git clone https://github.com/lexiaoau/kogan-test.git

cd kogan-test/

npm install

```

## Run

To run Code Chanllenge, use following commands:

```
cd kogan-test/

node src/index.js

```

## Features

After running, the program will retrive data from specified API and output the Average cubic weight for all products in the "Air Conditioners" category.



